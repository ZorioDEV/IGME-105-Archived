﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Backpack_PE
{
    /// <summary>
    /// Backpack class.
    /// Students will write the contents of this class themselves.
    /// </summary>
    internal class Backpack
    {
        // ****************************************************************
        // TODO: Write Backpack class code!


        // ****************************************************************

    }
}
