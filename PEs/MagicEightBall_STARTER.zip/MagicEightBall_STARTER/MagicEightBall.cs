﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MagicEightBall_STARTER
{

    // *****************************************
    // *** Add XML comments to this class!   ***
    // *****************************************

    internal class MagicEightBall
    {
        // --------------------------------------------------------------------
        // Fields of this class
        // --------------------------------------------------------------------

        // 2 included fields from the exercise
        private string[] responses;
        private Random randomGenerator;

        // *************************************************************
        // TODO: Declare the other 2 fields (owner and timesShaken) here!
        // *************************************************************




        // --------------------------------------------------------------------
        // Constructors of this class
        // --------------------------------------------------------------------

        // *****************************************
        // TODO: Add comments to this constructor!
        // *****************************************
        public MagicEightBall()
        {
            // Initialize the Random object.
            randomGenerator = new Random();

            // Initialize the responses array with 1 response.
            responses = new string[5];
            responses[0] = "It is certain";

            // *******************************************************
            // TODO: Assign 4 more responses to the responses array!
            // *******************************************************



            // *******************************************************
            // TODO: Assign default value to owner and timesShaken fields!
            // *******************************************************


        }

        // *****************************************************
        // TODO: Create parameterized constructor! Add XML comments!
        // *****************************************************






        // --------------------------------------------------------------------
        // Methods of this class
        // --------------------------------------------------------------------


        // *****************************************
        // TODO: Add XML comments to this method!
        // *****************************************
        public string ShakeBall()
        {
            // Randomly chooses one of the 5 possible responses
            // Next(0, 5) will return 0, 1, 2, 3, or 4.  
            int randomNumber = randomGenerator.Next(0, 5);

            // Retrieve that randomly chosen index from the responses array
            //   and save the value in a string variable.
            string randomResponse = responses[randomNumber];

            // *******************************************
            // TODO: Update times shaken!
            // *******************************************


            // *******************************************
            // TODO: Return randomly chosen response!
            // *******************************************

            // Change this to return the correct thing.
            return "";
        }


        // *****************************************************
        // TODO: Create the Report method here! Add XML comments!
        // *****************************************************



    }
}
